declare module "turbolinks";
declare module "body-scroll-lock";
declare module "scriptjs";
declare module "@heintouchable/functions";
