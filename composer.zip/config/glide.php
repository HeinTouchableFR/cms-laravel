<?php
return [
  'key' => env('GLIDE_KEY', 'local')
];
